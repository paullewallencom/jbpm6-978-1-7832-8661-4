package com.wordpress.marianbuenosayres.service;

public interface NotifierService {

	void sendWarning(String warning);
}
