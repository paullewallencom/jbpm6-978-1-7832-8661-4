package com.wordpress.marianbuenosayres.model;

import java.io.Serializable;

public class ProcessCreationTrigger implements Serializable {

	private static final long serialVersionUID = 3271877931717694639L;
}
